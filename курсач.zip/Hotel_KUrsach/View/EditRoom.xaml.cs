﻿using Hotel.Model;
using Hotel.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hotel.View
{
    /// <summary>
    /// Логика взаимодействия для EditRoom.xaml
    /// </summary>
    public partial class EditRoom : Window
    {
        public EditRoom(Room EditRoom)
        {
            InitializeComponent();
            MainWindowVM.RomNumber = EditRoom.Number;
            MainWindowVM.RomFloor = EditRoom.Floor;
            MainWindowVM.RomType = EditRoom.Type;
            MainWindowVM.RomCapfcity = EditRoom.Capfcity;
            MainWindowVM.RomStatus = EditRoom.Status;
            MainWindowVM.RomPrice = EditRoom.Price;
        }
    }
}
